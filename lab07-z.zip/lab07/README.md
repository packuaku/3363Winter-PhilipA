# Lab 07 — Validation & Error Handling (JavaScript + PHP) 
 
**Student Name:** _Philip Ackuaku _________________________   
**Submission Date:** __2nd March 2026_______________________________   
 
## 1) How to Run 
1. Start **Apache** in XAMPP. 
2. Put this folder in: `C:\xampp\htdocs\winter3363\lab07\` 
3. Testing URL: http://localhost/winter3363/lab07/index.php

 --- 
 
## 2) Files Included (check) 
- [ check] `index.php` 
- [ check] `process.php` 
- [ check] `includes/helpers.php` 
- [ check] `assets/validation.js` 
- [ check] `assets/style.css` 
- [ check] `data/submissions.jsonl` 
- [ check] `logs/errors.log` 
 --- 
 
## 3) Validation Completed (check) 
### JavaScript (client-side) 
- [ check] Required fields blocked 
- [ check] Email format checked 
- [ check] Course code format checked (INTE####) 
- [ check] Rating checked (1–5) 
- [ check] Agree checkbox required 
- [ check] Errors show beside fields 
- [ check] Prevent submit when invalid 
 
### PHP (server-side) 
- [ check] Validates the same rules again 
- [ check] Shows errors beside fields 
- [ check] Keeps sticky values (old input stays) 
- [ check] Uses `try/catch` for saving file 
- [ check] Logs errors to `logs/errors.log` 
 --- 
 
## 4) Testing Checklist (Required) 
Fill in Pass/Fail. 
 
| Test | Pass/Fail | 
|------|----------| 
| Empty submit shows errors | __Pass_ | 
| Invalid email blocked | _Pass__ | 
| Invalid course code blocked | __Pass_ | 
| Rating out of range blocked | _Pass__ | 
| Agree unchecked blocked | _Pass__ | 
| Disable JS (comment out script tag) → PHP still blocks invalid data | _Pass__ | 
| Valid submit saves to `submissions.jsonl` | _Pass__ | 
 --- 
 
## 5) Compare JavaScript vs PHP Validation (What I learned) 
Fill in 1–2 sentences for each. 
 
**JavaScript validation is good for:**  
It improves UX (fast feedback before submit). __________________________________________________________________  
 
**JavaScript validation is NOT reliable for security because:**  
It runs in the browser and can be disabled, modified, or bypassed using developer tools or direct POST requests.__________________________________________________________________  
 
**PHP validation is important because:**  
PHP validation is the final authority that protects the server and data. _________________________________________________________________  
 
**One example from my testing (disable JS) that proved PHP is needed because:**  
After commenting out the </*script*/> tag and refreshing the page, I submitted an empty form and the JavaScript was disabled. Because of that, PHP  blocks the submission and displays validation errors marked “validated by PHP,” proving that the server enforces the rules and protects the server and its data. __________________________________________________________________ 