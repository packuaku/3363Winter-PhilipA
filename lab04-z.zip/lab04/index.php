<?php
/*
Lab 04 Documentation Page (Template)
REQUIRED FILE LOCATION (for this course):
- Save this file as: index.php
- Save it in: C:\xampp\htdocs\winter3363\lab04\index.php
INSTRUCTIONS FOR STUDENTS:
- You MUST edit every area marked "STUDENT TODO" so it matches YOUR database and tables.
- Database naming rule: lab04_yourfirstname
Example: lab04_sherry
DEMO NOTE (Instructor):
- Instructor demo database name may be: lab04_demo
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>lab04_philip - MySQL Fundamentals Documentation</title>
<style>
body { font-family: Arial, sans-serif; margin: 24px; line-height: 1.5; }
h1, h2, h3 { margin-bottom: 6px; }
.meta { margin-top: 0; color: #333; }
code { background: #f3f3f3; padding: 2px 6px; border-radius: 4px; }
pre { background: #f3f3f3; padding: 12px; border-radius: 6px; overflow-x: auto; }
ul { margin-top: 6px; }
.section { margin-top: 18px; }
.note { color: #444; font-size: 0.95em; }
table { border-collapse: collapse; margin-top: 8px; width: 100%; max-width: 720px; }

th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
th { background: #f6f6f6; }
</style>
</head>
<body>
<h1>Lab 04: MySQL Fundamentals (phpMyAdmin)</h1>
<p class="meta">
<strong>Name:</strong>

Philip Ackuaku
<br>
<strong>Date:</strong>

2026-02-01
</p>
<div class="section">
<h2>Database</h2>
<p>
<strong>Instructor demo database name:</strong>
<code>lab04_demo</code>
<br>
<span class="note">
Students: your database name must follow the course rule below.
</span>
</p>

<p>
<strong>Student database naming rule:</strong>

<code>lab04_philip</code>
</p>
</div>
<div class="section">
<h2>Tables and Purpose</h2>
<ul>
<li>
<strong>customers</strong>


— Stores customer information (one row per customer).
</li>
<li>
<strong>orders</strong>

— Stores order records (one row per order) and links each order to a customer using <code>customer_id</code>.
</li>
</ul>
</div>
<div class="section">
<h2>Table Fields (Columns)</h2>
<h3>customers</h3>
<ul>
    
<li><code>customer_id</code> — INT (PRIMARY KEY, AUTO_INCREMENT)</li>
<li><code>first_name</code> — VARCHAR(50)</li>
<li><code>last_name</code> — VARCHAR(50)</li>
<li><code>email</code> — VARCHAR(100)</li>
</ul>
<h3>orders</h3>
<ul>

<li><code>order_id</code> — INT (PRIMARY KEY, AUTO_INCREMENT)</li>
<li><code>customer_id</code> — INT (FOREIGN KEY → <code>customers.customer_id</code>)</li>
<li><code>order_date</code> — DATE</li>
<li><code>total_amount</code> — DECIMAL(8,2)</li>
<li><code>status</code> — VARCHAR(20)</li>
</ul>
<p class="note">
Relationship: <code>orders.customer_id</code> connects each order to a customer in <code>customers</code>.
</p>
</div>
<div class="section">
<h2>Sample Data Inserted (at least 3 rows per table)</h2>
<h3>Customers (example)</h3>
<table>
<thead>
<tr>
<th>Customer</th>
<th>Email</th>
</tr>
</thead>
<tbody>

<tr><td>Kofi Smith</td><td>kofi.smith@yahoo.com</td></tr>
<tr><td>Vershard Lewis</td><td>lewis.vershard@gmail.com</td></tr>
<tr><td>James Bureau</td><td>Jbureau@hotmail.com</td></tr>
<tr><td>Victoria Anderson</td><td>Andersonvic@yahoo.com</td></tr>
</tbody>
</table>
<h3>Orders (example)</h3>
<p class="note">
</p>
<table>
<thead>
<tr>
<th>Order Date</th>
<th>Total Amount</th>
<th>Status</th>
</tr>
</thead>
<tbody>

<tr><td>2026-01-21</td><td>87.57</td><td>Paid</td></tr>
<tr><td>2026-01-28</td><td>50.25</td><td>Unpaid</td></tr>
<tr><td>2026-01-25</td><td>60.25</td><td>Unpaid</td></tr>
<tr><td>2026-01-31</td><td>20.28</td><td>Paid</td></tr>
</tbody>
</table>
</div>
<div class="section">
<h2>Sample SQL Queries (run in phpMyAdmin → SQL tab)</h2>
<p class="note">
Your screenshots should include at least one JOIN query showing the relationship between your two tables.
</p>
<pre><code>SELECT * FROM customers;</code></pre>
<pre><code>SELECT * FROM orders
ORDER BY total_amount DESC;</code></pre>
<pre><code>SELECT c.customer_id, c.first_name, c.last_name, c.email,
o.order_id, o.order_date, o.total_amount, o.status
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
ORDER BY o.order_date DESC;</code></pre>
</div>
<div class="section">
<h2>Export Confirmation</h2>
<p>
I exported my database from phpMyAdmin as:
<code>lab04_philip.sql</code>
<br>
and saved it in:
<code>C:\xampp\htdocs\winter3363\lab04\lab04_philip</code>
</p>
<p class="note">
Example (instructor demo): database name <code>lab04_demo</code> could export to <code>lab04_demo.sql</code>.
</p>
</div>
</body>
