<?php
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/functions.php";

$errors = [];
$full_name = "";
$email = "";
$program = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $full_name = trim($_POST["full_name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $program = trim($_POST["program"] ?? "");

    // Validation
    if ($full_name === "") $errors[] = "Full name is required.";
    if ($email === "") $errors[] = "Email is required.";
    if ($email !== "" && !is_valid_email($email)) $errors[] = "Email format is invalid.";

    if ($program === "") $errors[] = "Program is required.";
    if (!$errors) {
        try {
            $sql = "INSERT INTO students (full_name, email, program)
                    VALUES (:full_name, :email, :program)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ":full_name" => $full_name,
        ":email" => $email,
        ":program" => $program
    ]);

    redirect("index.php?msg=created");
        }  catch (PDOException $e) {

            // Common beginner issue: duplicate email (UNIQUE)
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

?>
<?php require_once __DIR__ . "/../includes/header.php"; ?>

<h2>Add Student</h2>

<?php if ($errors): ?>
    <div class="error">
        <strong>Please fix the following:</strong>

        <ul>
            <?php foreach ($errors as $err): ?>
                <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" action="create.php" novalidate>
    <label>Full Name</label>
    <input type="text" name="full_name" value="<?= e($full_name) ?>" />

    <label>Email</label>
    <input type="email" name="email" value="<?= e($email) ?>" />

    <label>Program</label>
    <input type="text" name="program" value="<?= e($program) ?>" />

    <div class="form-actions">
        <button class="btn" type="submit">Create</button>
        <a class="btn" href="index.php">Cancel</a>
    </div>
</form>
<?php require_once __DIR__ . "/../includes/footer.php"; ?>