# Lab 05 - PHP + MySQL CRUD (PDO) 

## Student Info 
- Name: Firstname Lastname 
- Course: Advanced Web Design & Development 
- Lab: 05 

## Database 
- Database name: lab05_philip 
- Table: students 

### Schema (SQL) 
```sql 
CREATE TABLE students ( 
    student_id INT AUTO_INCREMENT PRIMARY KEY, 
    full_name VARCHAR(100) NOT NULL, 
    email VARCHAR(120) NOT NULL UNIQUE, 
    program VARCHAR(80) NOT NULL, 
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP 
); 
``` 
## How to Run (Local)
1. Start XAMPP: Apache + MySQL 
2. Put project here: - C:\xampp\htdocs\winter3363\lab05\ 
3. Open: 
    - http://localhost/winter3363/lab05/public/
## Features Completed 
- [ ] PDO connection (db.php) 
- [ ] READ (index.php) 
- [ ] CREATE (create.php) 
- [ ] UPDATE (edit.php) 
- [ ] DELETE (delete.php) 
- [ ] Prepared statements used everywhere 
- [ ] Output escaped with htmlspecialchars 

## Screenshots (Required) 
Submit required screenshots in a file to Moodle. 
## Notes / Challenges 
Write 2-3 sentences about what you learned from Lab 05.

I learnt how to connect my database to my code on virtual studio code.
I also learnt how to create an interactive webpage where I can store, edit and delete data. 