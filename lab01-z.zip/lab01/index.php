<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 <title>Lab 01 - Hello PHP</title>
</head>
<body>
 <?php
 $firstName = "Philip"; // TO DO: Replace "First" with your FIRST NAME
 $lastName = "Ackuaku"; // TO DO: Replace "Last" with your LAST NAME
 ?>
 <h1>Hello World! This is my first PHP test.</h1>
 <p>My name is <?php echo $firstName . " " . $lastName; ?></p>
 <p><a href="phpinfo.php">Open phpinfo()</a></p>
</body>
</html>