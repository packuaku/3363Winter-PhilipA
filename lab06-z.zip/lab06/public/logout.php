<?php 
declare(strict_types=1); 

require_once __DIR__ . "/../app/config.php"; 

// Clear session data 
$_SESSION = [];

// Destroy session cookie (best practice) 
if (ini_get("session.use_cookies")) { 
    $params = session_get_cookie_params(); 
    setcookie(session_name(), "", time() - 42000, 
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"] 
    ); 
} 

session_destroy(); 
header("Location: login.php"); 
exit;