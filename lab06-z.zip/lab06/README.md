# Lab 06 — PHP Web Security & Sessions (Secure Notes)
**Student Name:** Philip Ackuaku
**Date:** Sunday 15th February 2026
## 1) What I built (1–2 sentences)
I built a sign up page that enables users to create an account and succesfully log into their created account. This page also connects to other pages such as the dasboard page, login page as well as the create notes pages that mimics the next steps after creating an account on this webpage. 
____________________________________________________________________
____________________________________________________________________
## 2) How to run my lab
**Database name:** `lab06_yourfirstname'
**Start page URL:**
Steps:
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin and create my database
3. Run the Lab06 SQL to create tables: `users`, `notes`
4. Update `app/db.php` with my DB name
5. Open the start page URL above

## 3) Security features checklist:
## 4) Test Results (PASS/FAIL)
- Register works: PASS
- Login works (correct password): PASS
- Login fails (wrong password): PASS
- Dashboard redirects when logged out: PASS
- Create note works: PASS
- XSS test does NOT run (`<script>alert('xss')</script>`): PASS
- Admin page (user gets 403): PASS
- Admin page (admin can view): PASS
- Session timeout works: PASS
## 5) Reflection: what I have learned from Lab 06 (3-5 sentences)

I learnt how to store and create a new user for a webpage. I learnt how to authenticate passwords and to create secure logins for different users. I learnt how to restrict access to users and to provide control to the main administer. 