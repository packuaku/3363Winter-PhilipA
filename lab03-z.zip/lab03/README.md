# Login Demo (PHP Sessions)

## How to run (XAMPP)
1. Start **Apache** in XAMPP.
2. Put this folder at:
   `C:\xampp\htdocs\3363winter\log-in-out\`
3. Open in browser:
   http://localhost/3363winter/log-in-out.php

## Demo credentials
- Email: student@example.com
- Password: Password123!

## Concepts
- POST form handling
- Required checks on the server
- Sessions for login state
- Escaping output with htmlspecialchars()


## Project Title: 
- Creating a log in and log out page 
- This lab focused on creating a successful log in and log out page, that required users to input a username and password in order to log in and use the page. 

## What I learnt: 
- I learnt how to create a required form using php and how to integrate html into a php code. 